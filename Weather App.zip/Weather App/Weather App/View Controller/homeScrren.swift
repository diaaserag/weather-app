//
//  ViewController.swift
//  Weather App
//
//  Created by diaa on 16/08/2021.
//
import Alamofire
import SwiftyJSON
import UIKit
import CoreLocation
let appID = "c5988b924bf9c7fe6812fbfd91211af2"
let URL = "https://api.openweathermap.org/data/2.5/weather?"
class homeScrren: UIViewController,CLLocationManagerDelegate,changcitydelegate {
    func userinternewcityname(city: String) {
        print("i am in call")
        let param : [String:String] = ["q":city,"appid":appID]
        networkreqest(url: URL, para: param)
    }
    var data : myData = myData.init(name: "city", temp: 0.0, dis: "opps", codeID: 0)
    var locationManger = CLLocationManager()
    var cityName : String = ""
    @IBOutlet weak var lablCityName: UILabel!
    @IBOutlet weak var lablSkyCondition: UILabel!
    @IBOutlet weak var lablTempDegrre: UILabel!
    @IBOutlet weak var imageForDesc: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManger.delegate = self
        locationManger.desiredAccuracy = kCLLocationAccuracyKilometer
        locationManger.requestWhenInUseAuthorization()
        locationManger.startUpdatingLocation()
    }
}
//MARK:- location
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
extension homeScrren{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let dataLocation = locations[locations.count-1]
        if dataLocation.horizontalAccuracy > 0{
            locationManger.stopUpdatingLocation()
            locationManger.delegate = nil
            let latit = String (dataLocation.coordinate.latitude)
            let longti = String(dataLocation.coordinate.longitude)
            let parameters : [String:String] = ["lat":latit,"lon":longti,"appid":appID]
            print("i am in the location ")
            networkreqest(url: URL, para: parameters)
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("no location an error was happened")
        print(error)
    }
}
//MARK:- NETWORKING
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
extension homeScrren{
    func networkreqest(url:String , para:[String:String]){
        Alamofire.request(url, method: .get, parameters: para).responseJSON{response in
            if response.result.isSuccess{
                let weather : JSON = JSON(response.result.value!)
                self.weatherdata(json: weather)
            }
            else{
                print(Error.self)
            }
        }
    }
}
//MARK:- DEALWITHJSON
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
extension homeScrren
{
  func weatherdata(json:JSON){
    if let n = json["name"].string{
    let t = json["main"]["temp"].double!
    let d = json["weather"][0]["description"].string!
    let c = json["weather"][0]["id"].int!
    data = myData(name: n, temp: t, dis: d, codeID: c)
    }
    updateui()
    }
    func updateui(){
        lablCityName.text = data.name
        lablTempDegrre.text = "\(String(format: "%.2f", data.temp - 273.15))"
        lablSkyCondition.text = data.dis
        if data.codeID >= 200 && data.codeID <= 232{
            imageForDesc.image = UIImage(named: "thunderstorm")!
        }
        else if data.codeID >= 300 && data.codeID <= 321{
            imageForDesc.image = UIImage(named: "drizzle")!
        }
        else if data.codeID >= 500 && data.codeID <= 531{
            imageForDesc.image = UIImage(named: "rain")!
        }
        else if data.codeID >= 600 && data.codeID <= 622{
            imageForDesc.image = UIImage(named: "snow")!
        }
        else if data.codeID >= 701 && data.codeID <= 781{
            imageForDesc.image = UIImage(named: "mist")!
        }
        else if data.codeID >= 801 && data.codeID <= 804{
            imageForDesc.image = UIImage(named: "clouds")!
        }
        else if data.codeID != 0{
            imageForDesc.image = UIImage(named: "clear sky")!
        }
}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "changeCityName"{
            let des = segue.destination as! cityScrren
            des.delegate = self
        }
    }
}

struct myData {
    let name:String
    let temp:Double
    let dis:String
    let codeID:Int
}
