//
//  cityScrren.swift
//  Weather App
//
//  Created by diaa on 16/08/2021.
//

import UIKit
protocol changcitydelegate {
    func userinternewcityname(city:String)
}
class cityScrren: UIViewController {
    @IBOutlet weak var textFiledEnterCityName: UITextField!
    var delegate : changcitydelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func buttonGetWeather(_ sender: Any) {
    
        let cityname = textFiledEnterCityName.text
        delegate?.userinternewcityname(city: cityname!)
        dismiss(animated: true, completion: nil)
    }
}
